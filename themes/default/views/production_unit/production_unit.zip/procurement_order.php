<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= $assets ?>production_unit/css/style.css" rel="stylesheet" />
    <script type="text/javascript" src="<?= $assets ?>production_unit/js/procurment_orders.js"></script>

    <!-- <link href="<?= $assets ?>styles/style.css" rel="stylesheet" /> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- Include Redactor.js script -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/redactor/3.5.4/redactor.js"></script>
    <!-- Include Redactor.css for styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/redactor/3.5.4/redactor.css">
</head>

<body>
    <section id="procurement_order">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2 p-0 bg-setting">
                    <div class="box-header">
                        <h2 class="blue"><i class="fa-fw fa fa-barcode icon-th"></i><span class="break"></span>Orders
                        </h2>
                    </div>

                    <div class="mrgn-tp">
                        <ul class="nav nav-tabs nav-justified m-4 nav-set" role="tablist">
                            <!-- <li class="nav-item  p-0 mt-1">
                                <a class="nav-link bg-set status"  data-toggle="tab"
                                    value="current_order" href="#" role="tab">Current Order</a>
                            </li> -->
                             <li class="nav-item p-0 mt-1 active" id ="activeStatus">
                                <a class="nav-link bg-set status"  data-toggle="tab" href="" value="current_order" role="tab">Current Order
                    
                                </a>
                            </li>
                            <li class="nav-item p-0 mt-1">
                                <a class="nav-link bg-set status" data-toggle="tab" href="" value="Open" role="tab">Open
                                    Orders
                                </a>
                            </li>
                            <li class="nav-item p-0 mt-1">
                                <a class="nav-link bg-set status" data-toggle="tab" href="" value="partially"
                                    role="tab">Partial
                                    Orders</a>
                            </li>
                            <li class="nav-item p-0 mt-1" id ="previous_order">
                                <a class="nav-link bg-set status" data-toggle="tab" href="" value="previous_order"
                                    role="tab">Previous Orders
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
                <div class="col-md-8 sty-bg-set">
                    <div class="d-flex align-items-center set-bg-8">
                        <h3 class="m-0_10 font-weight mt-set">
                            Request a Delivery Date :
                        </h3>
                        <form>
                            <div class="input-group w-set">
                                <input type="text" id="birthday" name="birthday" class="form-control"
                                    placeholder="Select a date">
                                <span class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </span>
                            </div>
                        </form>
                        <div class="">
                            <button class="reset-btn" id = "reset">Reset</button>
                        </div>
                        <div class="w-set1 ml-auto">
                            <h4>
                                <i class="fa fa-people"> </i> <span id="userName"></span>
                            </h4>
                        </div>
                    </div>
                    <div class="tab-content overflowset">
                        <div class="tab-pane fade in active text-center" role="tabpanel">
                            <h3 class="m-0_10 mb-2 text-left" id="order_status"></h3>

                            <div class="col-md-12 p-0">
                                
                                <table class="table table-bordered rounded-table text-center" id="dynamicTable">
                                    <thead>
                                    </thead>
                                    <tbody class="text-center">
                                    </tbody>
                                    <tfoot >
                                    </tfoot>
                                </table>
                                <button class="btn repeat_order" id="repeat_order" style="display: none; border: 2px solid #039be5;"  value="current_order" type="submit">Repeat Order</button>
                                <div class="col-md-12" id="editorRow"  style="display: none;">
                                    <div>
                                        <textarea id="editor"></textarea>
                                    </div>
                                </div>
                                <button class="btn place_order" id="place_order" style="display: none; border: 2px solid #039be5;"  value="place_order" type="submit">Place Order</button>
                                <button class="btn add_note" id="add_note" style="display: none; border: 2px solid #039be5;"  value="place_order" type="submit">Add Note</button>
                              

                                <!-- <div class="d-flex row col-md-12 p-0">
                                    <button class="btn" id="btn-hide1" style="display: none;" type="submit">Place
                                        Order</button>

                                    <button class="btn" id="btn-hide112" style="display: none;" type="submit">
                                        <i class="fa fa-file-text-o mr-set"></i> Add Note </button>
                                </div> -->
                            </div>
                            <!-- <div class="col-md-12 p-0" id="orderTable1" style="display: none;">
                               
                                <button class="btn" id="btn-hide11" style="display: none;" type="submit">Place
                                    Order</button>
                            </div> -->
                            <!-- <div class="col-md-12 p-0" id="orderTable1" style="display: none;"> -->
                                <!-- <table id="" class="table table-bordered rounded-table" style="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Category</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Qty.</th>
                                            <th scope="col">Unit</th>
                                            <th scope="col">Sub Total</th>
                                            <th scope="col">Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    </tbody>
                                </table> -->
                                <!-- <button class="btn" id="btn-hide12" style="" type="submit">Place
                                    Order</button> -->
                            <!-- </div> -->
                        </div>
                        <!-- <div class="tab-pane fade" id="tabs-2" role="tabpanel"> -->
                            <!-- <h3 class="m-0_10 mb-2">All Open Orders</h3> -->
                            <!-- <div class="col-md-12 p-0" id="update_Orders">
                                <table class="table table-bordered rounded-table" id="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Order #</th>
                                            <th scope="col">Total Items</th>
                                            <th scope="col">Placed On</th>
                                            <th scope="col">Placed By</th>
                                            <th scope="col">Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="text-center">
                                            <td>#A1B2C3D4E5</td>
                                            <td>3</td>
                                            <td>05/10/2024</td>
                                            <td>@Jane D</td>
                                            <td><a href="#" id="updateOrderLink" class="update-link">Update Order</a>
                                            </td>
                                        </tr>
                                        <tr class="text-center">
                                            <td>#Z0Y9X8W7V6</td>
                                            <td>5</td>
                                            <td>05/10/2024</td>
                                            <td>John K</td>
                                            <td><a href="#" id="updateOrderLink" class="update-link">Update Order</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div> -->
                            <!-- <div class="text-center col-md-12 p-0" id="orderTable12" style="display: none;">
                                <table id="" class="table table-bordered rounded-table" style="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Category</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Qty.</th>
                                            <th scope="col">Unit</th>
                                            <th scope="col">Sub Total</th>
                                            <th scope="col">Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    </tbody>
                                </table>
                                <button class="btn" id="btn-hide1" type="submit">Update Order</button>
                            </div> -->
                        <!-- </div> -->
                        <!-- <div class="tab-pane fade" id="tabs-3" role="tabpanel"> -->
                            <!-- <h3 class="m-0_10 mb-2">Partially Received Orders</h3> -->
                            <!-- <div class="col-md-12 p-0" id="Partial_Orders">
                                <table class="table table-bordered rounded-table" id="Partial_Orders">
                                    <thead>
                                        <tr>
                                            <th scope="col">Order #</th>
                                            <th scope="col">Total Items</th>
                                            <th scope="col">Placed On</th>
                                            <th scope="col">Placed By</th>
                                            <th scope="col">Received On</th>
                                            <th scope="col">Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="text-center">
                                            <td>#A1B2C3D4E5</td>
                                            <td>3</td>
                                            <td>05/10/2024</td>
                                            <td>@Jane D</td>
                                            <td>05/12/2024</td>
                                            <td><a href="#" id="viewOrderLink" class="view-link">View</a></td>
                                        </tr>
                                        <tr class="text-center">
                                            <td>#Z0Y9X8W7V6</td>
                                            <td>5</td>
                                            <td>05/10/2024</td>
                                            <td>John K</td>
                                            <td>05/12/2024</td>
                                            <td><a href="#" id="viewOrderLink" class="view-link">View</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div> -->
                            <!-- <div class="col-md-12 p-0 text-center" id="orderTable2" style="display: none;">
                                <table id="" class="table table-bordered rounded-table" style="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Category</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Qty.<br>
                                                Requested.</th>
                                            <th scope="col">Qty.<br>
                                                Received</th>
                                            <th scope="col">Difference</th>
                                            <th scope="col">Add to Current Order</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    </tbody>
                                </table>
                                <button class="btn" id="btn-hide1" type="submit"> Go to Current Order</button>
                            </div> -->
                        <!-- </div> -->

                        <!-- <div class="tab-pane fade" id="tabs-4" role="tabpanel"> -->
                            <!-- <h3 class="m-0_10 mb-2">Previous Orders</h3> -->
                            <!-- <div class="col-md-12 p-0" id="Received_orders">
                                <table class="table table-bordered rounded-table" id="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Order #</th>
                                            <th scope="col">Total Items</th>
                                            <th scope="col">Placed On</th>
                                            <th scope="col">Placed By</th>
                                            <th scope="col">Received On</th>

                                            <th scope="col">View Order</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="text-center">
                                            <td>#A1B2C3D4E5</td>
                                            <td>3</td>
                                            <td>05/10/2024</td>
                                            <td>@Jane D</td>
                                            <td>05/12/2024</td>
                                            <td><a href="#" id="viewOrderLink1" class="view-link1">View</a></td>
                                        </tr>
                                        <tr class="text-center">
                                            <td>#Z0Y9X8W7V6</td>
                                            <td>5</td>
                                            <td>05/10/2024</td>
                                            <td>John K</td>
                                            <td>05/12/2024</td>
                                            <td><a href="#" id="viewOrderLink1" class="view-link1">View</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div> -->
                            <!-- <div class="col-md-12 p-0 text-center" id="orderTable3" style="display: none;">
                                <table id="" class="table table-bordered rounded-table" style="">
                                    <thead>
                                        <tr>
                                            <th scope="col">Category</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Qty.<br>
                                            <th scope="col">Unit<br>
                                            <th scope="col">Sub Total</th>

                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    </tbody>
                                </table>
                            </div> -->
                        <!-- </div> -->
                    </div>

                </div>
                <div class="col-md-2 p-0 bg-setting right_section" style="display: none;">
                    <div class="search-container">
                        <form action="search.php" method="GET">
                            <input type="text" placeholder="Search..." name="query" class="search-box">
                            <button type="submit" class="search-button"><i class="fa fa-search"></i></button>
                        </form>
                    </div>

                    <div class="row mrgn-tp padding-set">
                        <div class="" style="height: 500px; overflow-y: auto;">
                        <ul class=" menu-list recentClick">
                                <!-- <li class = "btn btn-sty">darade</li> -->
                            </ul>
                            <ul class=" menu-list categoriesList">
                                <!-- <li class = " categoriesList"></li>
                                <li class = "btn btn-sty subcategoriesList"></li> -->
                            </ul>
                            <ul class="menu-list subcategoriesList">
                            </ul>
                            <ul class="menu-list productList">
                            </ul>

                        </div>
        
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
<script>
    var categories = <?php echo json_encode($categories); ?>;
    console.log(categories)
</script> 
</html>