<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Production_Unit extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->loggedIn) {
            $this->session->set_userdata('requested_page', $this->uri->uri_string());
            $this->sma->md('login');
        }
        $this->load->model('production_unit_model');
        $this->load->database(); // Database library
        $this->load->library('datatables');
    }

    function index($warehouse_id = NULL) {
        $this->sma->checkPermissions();

        $this->data['locationNames'] = $this->production_unit_model->getLocations();      
        $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');
        $bc = array(array('link' => base_url(), 'page' => lang('Production_Unit')), array('link' => '#', 'page' => lang('Order_Dispatch')));
        $meta = array('page_title' => lang('Production_Unit'), 'bc' => $bc);
        $this->page_construct('production_unit/order_dispatch', $meta, $this->data);
    }
    
    public function getProcurementRefrenceNo($warehouse_id = NULL) {
        
        $locationName       = $_GET['location']; 
        $status             = $_GET['status'];
        $procurmentRefNo    = $_GET['procurmentRefNo'];
        $itemId             = $_GET['itemId']; 
        $quantity           = $_GET['quantity'];
        $itemData           = $_GET['itemData'];
        $checkbox           = $_GET['checkbox'];
        $Filter             = $_GET['Filter'];
        $Complete_order     = $_GET['Complete_order'];
        $deliveryDateTime   = $_GET['deliveryDateTime'];

        //update planned_delivery_datetime after set delivery time for orders
        if($deliveryDateTime){
            $datetime = [
                'id' => $procurmentRefNo,
                'planned_delivery_datetime' => $deliveryDateTime
            ];
            $this->production_unit_model->updateOrderItemStock($quantity, $itemId, $itemData, $procurmentDetails, $checkbox, $Complete_order, $datetime); //update status after click on locked button and also click on complete order button
        } 
        if($checkbox == 1 || $checkbox == 0){
            $this->production_unit_model->updateOrderItemStock($quantity, $itemId, $itemData, Null, $checkbox); // update status, allot qty and stock after check and uncheck on checkbox
        }
        $refrenceNo = $this->production_unit_model->getProcurementRefrenceNo($locationName, $Filter);
        $procurmentId = [ ];
        foreach ($refrenceNo as  $value) {
            $procurmentId[] = $value->itemId;
        } 
        
        $procurmentsDetail = ''; 
        if ($status || $procurmentRefNo) {
           
            $this->db->select('poi.id as itemId, poi.procurement_orders_id, poi.product_id, poi.product_name, poi.product_code,poi.order_quantity, poi.allot_quantity, po.procurement_order_ref_no, po.location_name, po.note, poi.item_status, productionunit_products.stock_quantity as stock_quantity,productionunit_products.open_order_quantity');
            $this->db->from('sma_procurement_order_items poi');
            $this->db->join('products ', 'products.id = poi.product_id', 'left');
            $this->db->join('productionunit_products ', 'productionunit_products.product_id = products.id', 'left');
            $this->db->join('sma_procurement_orders po', 'po.id = poi.procurement_orders_id');
            // if ($status) {
            //     $this->db->where('poi.item_status', $status);
            // }
            if ($status == 'Completed') {
                // Condition for Completed Items tab 
                $this->db->where('poi.order_quantity = poi.allot_quantity', null, false);
            } elseif ($status == 'Partially Completed') {
                // Condition for Partially Completed Items tab 
                $this->db->where('poi.order_quantity > poi.allot_quantity AND poi.allot_quantity > 0');
            } elseif ($status == 'Pending') {
                // Condition for Pending Items tab 
                $this->db->where('(poi.allot_quantity = 0 OR poi.allot_quantity IS NULL)');
            }
            if ($procurmentRefNo) {
                $this->db->where('poi.procurement_orders_id', $procurmentRefNo);
            }
            $this->db->order_by("poi.id", "DESC");
            $procurmentsDetail = $this->db->get()->result();
            $procurmentDetails = $procurmentsDetail;
            $this->production_unit_model->updateOrderItemStock($quantity = null, $itemId = null, $itemData = null, $procurmentDetails, null, $Complete_order); //update status after click on locked button and also click on complete order button

        } else {
            $procurmentDetails = $this->production_unit_model->getProcurementdetails($procurmentId, $status = null);
            foreach ($procurmentDetails as $item) {
                if ($item->item_status == "completed") {
                    $item->open_order_quantity = 0;
                }
            }
        }        
        $pr[] = ['refrenceNo' => $refrenceNo, 'procurmentDetails' => $procurmentDetails];
        echo json_encode($pr);
        return;

    }
    //Procurment Orders 
    public function procurementOrders() {

    $this->sma->checkPermissions();
    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');
    $this->data['categories']  = $this->production_unit_model->getProdCategories();     
    $bc = array(array('link' => base_url(), 'page' => lang('Production_Unit')), array('link' => '#', 'page' => lang('Procurement_order')));
    $meta = array('page_title' => lang('Production_Unit'), 'bc' => $bc);
    $this->page_construct('production_unit/procurement_order', $meta, $this->data,$data);
    }
    //////////////////////////////////////////  PROCURMENT ORDER //////////////////////////////////////
    public function procurmentOrdersSuggection() {     

        // Example PHP controller endpoint
            $status          = $this->input->get('orderStatus');
            $order_id        = $this->input->get('order_id');
            $subcategoryId   = $this->input->get('subcategoryId');
            $categoriesId    = $this->input->get('categoriesId');
    
            if ($subcategoryId || $categoriesId) {
                $productsByCat  = $this->production_unit_model->getPrdCategories($categoriesId,$subcategoryId);    
            }
            if ($status) {
                $getOrderData  = $this->production_unit_model->getProcurmentOrders($status);      
            }
            if ($order_id) {
                $item_data     = $this->production_unit_model->getOrdersByItems($order_id);
            }
            $pr[] = ['productsByCat' => $productsByCat, 'getOrderData' => $getOrderData,'item_data' =>$item_data];
            echo json_encode($pr);
            return;
        }
      
}
?>